// AI Master — secure Gemini backend for Vercel
// DO NOT put the Gemini API key in index.html or GitHub.
// Vercel Environment Variable name: GEMINI_API_KEY

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const { message, history = [] } = req.body || {};
    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "Message is required" });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({
        error: "GEMINI_API_KEY is missing in Vercel Environment Variables."
      });
    }

    const safeHistory = Array.isArray(history)
      ? history.slice(-12).filter(x =>
          x && (x.role === "user" || x.role === "model") &&
          typeof x.text === "string"
        )
      : [];

    const contents = [
      ...safeHistory.map(x => ({
        role: x.role,
        parts: [{ text: x.text.slice(0, 6000) }]
      })),
      {
        role: "user",
        parts: [{ text: message.slice(0, 12000) }]
      }
    ];

    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{
              text:
                "You are AI Master Assistant. Give accurate, useful answers. " +
                "When the user writes Hindi/Hinglish, reply in simple Hindi/Hinglish. " +
                "For study questions, explain step-by-step with examples. " +
                "For coding questions, give practical copy-paste-friendly guidance. " +
                "Do not claim an action was completed unless it actually was."
            }]
          },
          contents,
          generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 1200
          }
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      console.error("Gemini API error:", data);
      return res.status(502).json({
        error: data?.error?.message || "Gemini request failed."
      });
    }

    const reply = data?.candidates?.[0]?.content?.parts
      ?.map(p => p.text || "")
      .join("")
      .trim();

    if (!reply) {
      return res.status(502).json({ error: "Gemini returned an empty response." });
    }

    return res.status(200).json({ reply });
  } catch (error) {
    console.error("AI Master server error:", error);
    return res.status(500).json({
      error: "Server error. Please try again."
    });
  }
}

AI Master secure Gemini setup

1. Upload index.html and the api folder to GitHub.
2. In Vercel: Project Settings -> Environment Variables.
3. Add GEMINI_API_KEY and paste your Gemini key there.
4. Redeploy the project.
Never put the real key in index.html, GitHub, or a public .env file.
